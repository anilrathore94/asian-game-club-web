<!DOCTYPE html>
<html>
    <head>   
        <meta charset="utf-8">  
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<meta http-equiv="X-UA-Compatible" content="IE=edge">  
		<title>Asian Games</title>  
		<!-- CSS -->	
		<link rel="stylesheet" href="../css/bootstrap.min.css">   
		<link rel="stylesheet" href="../css/style.css">
    </head>
	<body>  
		<div class="wrapper">       
		<!-- ================Sidebar================  -->      
		<nav id="sidebar">      
		 <div class="sidebar-header">      
			<h3>Asian Games</h3>              
			<strong>AG</strong>       
		 </div>          
		 <ul class="list-unstyled components">     
		  <li class="active"><a href=".././pages/index.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>    
		  <li><a href=".././manage_user/index.php"><i class="fas fa-car"></i><span>Manage user</span></a></li>		
		  <li><a href=".././page_setting/index.php"><i class="fas fa-tv"></i><span>Page Setting</span></a></li>     
		  <li><a href=".././manage_bank_card/index.php"><i class="fas fa-tv"></i><span>Manage Bank Card</span></a></li>    
		      
		  <li>
		    <a href=".././winning_management/index.php" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
		    <i class="fas fa-user-friends"></i><span>Winning Management</span></a>                 
					<ul class="collapse list-unstyled" id="pageSubmenu">                        
		              <li><a href="agent.html">Agent</a></li> 
		              <li><a href="adminmange.html">Admin</a></li>		
					  <li><a href="enduser.html">End User</a></li>
		      </ul> 
		  </li> 


		 

		  <li>
		    <a href=".././reports/index.php" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
		    <i class="fas fa-user-friends"></i><span>Reports</span></a>                 
					<ul class="collapse list-unstyled" id="pageSubmenu1">                        
		              <li><a href="agent.html">Agent</a></li> 
		              <li><a href="adminmange.html">Admin</a></li>		
					  <li><a href="enduser.html">End User</a></li>
		      </ul> 
		  </li> 

		  <li>
		    <a href=".././withdrawal/index.php" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
		    <i class="fas fa-user-friends"></i><span>Withdrawal Management</span></a>                 
					<ul class="collapse list-unstyled" id="pageSubmenu11">                        
		              <li><a href="agent.html">Agent</a></li> 
		              <li><a href="adminmange.html">Admin</a></li>		
					  <li><a href="enduser.html">End User</a></li>
		      </ul> 
		  </li> 
            <li><a href=".././recharge_request/index.php"><i class="fas fa-tv"></i><span>Recharge Request </span></a></li>
            
		   
		 </ul>         
		</nav>     
		<!-- =======================Page Content=====================  -->  
		<div id="content">         
			<nav class="navbar navbar-expand-lg navbar-light">      
				<div class="container-fluid">               
					<button type="button" id="sidebarCollapse" class="btn">     
						<i class="fas fa-bars"></i>                      
						<!-- <span>Toggle Sidebar</span> -->             
					</button>               
					<div class="admin-panel">       
						<ul class="ml-auto">          
							<li>						
								<a href="#profilemenu" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle">
								<img src="images/Pixabay.png" /></a>						
								<ul class="collapse list-unstyled drop-list" id="profilemenu">								
									<li><a href="#">Agent</a></li> 
									<li><a href="#" >Admin</a></li>		
									<li><a href="#">End User</a></li>	
								</ul>						
							</li> 						
							<li>Admin</li>						
							<li>				
								<a href="#adminbmenu" data-toggle="dropdown" aria-expanded="false" class="dropdown-toggle">
								<img src="images/eng.png" /></a>		
								<ul class="collapse list-unstyled drop-list" id="adminbmenu">	
									<li><a href="#">Agent</a></li>	
									<li><a href="#">Admin</a></li>	
									<li><a href="#">End User</a></li>	
								</ul>								
							</li>							                
						</ul>            
					</div>            
				</div>     
			</nav>

			<div class="main-content">	