<?php include '../pages/header.php'; ?>

<?php include '../pages/sidemenu.php'; ?>


<h3>Active Users</h3>
<!--<div><button type="button" class="btn add-search" data-toggle="modal" data-target="#myModal" ><i class="fas fa-plus"></i> &nbsp; Create Admin</button></div>
             <style type="text/css">
               .search-admin {
                 margin-top: 25px;
                  border-bottom: 1px solid #dee3ff;
                   padding-bottom: 10px;
                    }
                    </style>	-->
                   <form action="/action_page.php" class="cust-searchbar">	
				  <div class="input-group">		
				 <input type="text" class="form-control" placeholder="Search" name="search">	
			    <!-- <div class="input-group-btn"> -->			
			   <!-- <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button> -->	
			  <!-- </div> -->		
			 </div>	
			</form>					
            <div class="users-table mt-4 mb-4">				 
              <div class="table-responsive">				  
                <table  class="table table-striped table-class" id= "table-id">					
                  <thead>					  
                    <tr>						
                    						
                      <th class="align-middle" scope="col">Real Name</th>						
                       <th class="align-middle" scope="col">Login Account</th>						
                        <th class="align-middle" scope="col">Email</th>
                         <th class="align-middle" scope="col" style="text-align: center;">Action</th>					 
                          </tr>					
                           </thead>					
                            <tbody>					  
                             <tr>						
                              					
                               <td class="align-middle"><strong>DaaLiane</strong></td>						
                                <td class="align-middle"><strong>13336477422</strong></td>	
                                 <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
								  <td class="align-middle align-right"><label class="switch">							
								   <input type="checkbox" checked><span class="slider round"></span></label> &nbsp;							
									<img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">							
									 <img src=".././images/Group 28.png">							
									  <img src=".././images/Group 31.png"> &nbsp;							
									   <!--<img src="images/ellipsis-v-solid.png">	-->					
										</td>					  
										 </tr>	
										  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 

													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  <tr>           
										           
											<td class="align-middle"><strong>DaaLiane</strong></td>           
											 <td class="align-middle"><strong>13336477422</strong></td>  
											  <td class="align-middle"><strong>Dalian@ww.com</strong></td> 
											   <td class="align-middle align-right"><label class="switch">             
												<input type="checkbox" checked><span class="slider round"></span></label> &nbsp;              
												 <img src=".././images/times-circle-solid.png" data-toggle="modal" data-target="#exampleModaldelete">             
												  <img src=".././images/Group 28.png">             
												   <img src=".././images/Group 31.png"> &nbsp;              
													<!--<img src="images/ellipsis-v-solid.png"> -->         
													</td>           
													 </tr> 
													  
														

								 


								


									 


									


														                        						  					
								   </tbody>				  
								  </table>	






								 </div>				
								<br>				
							   <div class="pagination users-table-pagination mt-1">				 
                    <div class="page-number">					
                       <p>Items per page</p>					                              
                      <div class="form-group page-drop-size"> 	
											 		<select class  ="form-control" name="state" id="maxRows">
														 <option value="5000">Show ALL Rows</option>
														 <option value="5">5</option>
														 <option value="10">10</option>
														 <option value="15">15</option>
														 <option value="20">20</option>
														 <option value="50">50</option>
														 <option value="70">70</option>
														 <option value="100">100</option>
														</select>												 		
									  	</div>
                   </div>					
	                 <div class="number-of-page"><p>1 - 5  of  12 </p></div>					
	                  <div class='pagination-container number-pn' >
				       <nav>
				         <ul class="pagination">            
                    <li data-page="prev" >
								      <span> <img src=".././images/prev.png"> <span class="sr-only">(current)</span></span>
								    </li>				  
                    <li data-page="next" id="prev">
								       <span> <img src=".././images/next.png"> <span class="sr-only">(current)</span></span>
								    </li>
				        </ul>
				      </nav>
			      </div>


            </div>	

          
            




           </div>			




 <!-- Update Status -->
<?php include '../pages/footer.php'; ?>